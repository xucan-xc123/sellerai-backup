@echo off
chcp 65001 >nul
:: SellerAI Backend Launcher
:: 从 .env 文件读取 Key 并传给 Python 进程

for /f "tokens=2 delims==" %%a in ('findstr "DEEPSEEK_API_KEY" .env') do set DEEPSEEK_API_KEY=%%a
for /f "tokens=2 delims==" %%a in ('findstr "SILICONFLOW_API_KEY" .env') do set SILICONFLOW_API_KEY=%%a

echo Starting SellerAI Backend on http://localhost:8000
echo Key loaded: %DEEPSEEK_API_KEY:~0,10%...

python app.py
pause
