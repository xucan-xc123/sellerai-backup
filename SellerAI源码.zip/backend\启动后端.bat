@echo off
chcp 65001 >nul
title SellerAI 后端 API

echo =================================
echo   SellerAI 后端 API
echo =================================
echo.

set DEEPSEEK_API_KEY=sk-a29e991690804089b774835b07d2b592

cd /d "E:\QClaw\Work-QClaw\sellerai-backend"

echo 启动后端 API (端口 8000)...
python app.py

pause
