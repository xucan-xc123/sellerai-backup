"use client";

import { useState, useCallback } from "react";
import { generateListing } from "@/lib/api";

export default function ListingGenerator() {
  const [chineseNotes, setChineseNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" } | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [genTitle, setGenTitle] = useState("");
  const [genBullets, setGenBullets] = useState<string[]>([]);
  const [genDescHtml, setGenDescHtml] = useState("");
  const [genKeywords, setGenKeywords] = useState<string[]>([]);

  const showToast = useCallback((message: string, type: "success" | "error") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  }, []);

  async function copyToClipboard(text: string, label: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(label);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      showToast("Copy failed — select and Ctrl+C manually", "error");
    }
  }

  async function handleGenerate() {
    if (!chineseNotes.trim()) {
      showToast("Please enter product notes first", "error");
      return;
    }
    setLoading(true);
    try {
      const data = await generateListing(chineseNotes);
      setGenTitle(data.title);
      setGenBullets(data.bullets);
      setGenDescHtml(data.description || "");
      setGenKeywords(data.keywords || []);
      showToast("Listing generated!", "success");
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : "Generation failed", "error");
    } finally {
      setLoading(false);
    }
  }

  function copyAll() {
    const full = [
      `Title: ${genTitle}`,
      "",
      "Bullet Points:",
      ...genBullets.map((b, i) => `  ${i + 1}. ${b}`),
      "",
      "Keywords:",
      genKeywords.join(", "),
    ].join("\n");
    copyToClipboard(full, "all");
  }

  function exportCsv() {
    const rows = [
      ["Field", "Content"],
      ["Title", `"${genTitle.replace(/"/g, '""')}"`],
      ["Bullet 1", `"${(genBullets[0] || "").replace(/"/g, '""')}"`],
      ["Bullet 2", `"${(genBullets[1] || "").replace(/"/g, '""')}"`],
      ["Bullet 3", `"${(genBullets[2] || "").replace(/"/g, '""')}"`],
      ["Bullet 4", `"${(genBullets[3] || "").replace(/"/g, '""')}"`],
      ["Bullet 5", `"${(genBullets[4] || "").replace(/"/g, '""')}"`],
      ["Keywords", `"${genKeywords.join(", ").replace(/"/g, '""')}"`],
    ];
    const csv = rows.map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sellerai-listing.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <section className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-text">Listing Generator</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input */}
          <div className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-text mb-2">
                Chinese Product Notes
              </label>
              <textarea
                value={chineseNotes}
                onChange={(e) => setChineseNotes(e.target.value)}
                rows={10}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl text-text placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-brand/30 focus:border-brand transition-colors resize-y"
                placeholder="Paste your Chinese product description here... e.g. 304不锈钢保温杯 500ml 保冷24小时..."
              />
            </div>
            <button
              onClick={handleGenerate}
              disabled={loading}
              className="w-full py-3 text-sm font-semibold text-white bg-brand hover:bg-brand-dark disabled:opacity-50 transition-colors rounded-xl shadow-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <>
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Generating...
                </>
              ) : (
                "🚀 Generate Listing"
              )}
            </button>
          </div>

          {/* Output */}
          <div>
            {loading && !genTitle ? (
              <div className="space-y-4">
                <div className="skeleton h-6 w-3/4" />
                <div className="skeleton h-4 w-full" />
                <div className="skeleton h-4 w-5/6" />
                <div className="skeleton h-4 w-4/6" />
                <div className="skeleton h-20 w-full" />
              </div>
            ) : genTitle ? (
              <div className="bg-white rounded-2xl border border-gray-200 p-6 space-y-5">
                {/* Title */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold uppercase text-text-muted tracking-wide">Title</span>
                    <button
                      onClick={() => copyToClipboard(genTitle, "title")}
                      className="text-xs text-brand hover:text-brand-dark transition-colors cursor-pointer"
                    >
                      {copied === "title" ? "Copied!" : "Copy"}
                    </button>
                  </div>
                  <p className="text-lg font-semibold text-text leading-snug">{genTitle}</p>
                </div>

                {/* Bullets */}
                <div>
                  <span className="text-xs font-semibold uppercase text-text-muted tracking-wide">Bullet Points</span>
                  <ul className="mt-2 space-y-2">
                    {genBullets.map((b, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-text">
                        <span className="font-semibold text-brand text-xs mt-0.5">{i + 1}.</span>
                        {b}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Description */}
                <div>
                  <span className="text-xs font-semibold uppercase text-text-muted tracking-wide">Description (HTML)</span>
                  <div className="mt-2 p-3 bg-gray-50 rounded-xl border border-gray-100 text-sm text-text overflow-auto max-h-40">
                    <div dangerouslySetInnerHTML={{ __html: genDescHtml }} />
                  </div>
                </div>

                {/* Keywords */}
                <div>
                  <span className="text-xs font-semibold uppercase text-text-muted tracking-wide">Keywords</span>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {genKeywords.map((kw) => (
                      <span key={kw} className="px-3 py-1 text-xs font-medium bg-brand/10 text-brand rounded-full">
                        {kw}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3 pt-2 border-t border-gray-100">
                  <button
                    onClick={copyAll}
                    className="flex-1 py-2 text-sm font-medium border-2 border-gray-200 rounded-xl hover:border-brand/30 transition-colors cursor-pointer"
                  >
                    {copied === "all" ? "Copied!" : "Copy All"}
                  </button>
                  <button
                    onClick={exportCsv}
                    className="flex-1 py-2 text-sm font-medium border-2 border-gray-200 rounded-xl hover:border-brand/30 transition-colors cursor-pointer"
                  >
                    Export CSV
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-dashed border-gray-300 p-12 text-center">
                <p className="text-text-muted text-sm">Your generated listing will appear here.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {toast && <div className={`toast toast-${toast.type}`}>{toast.message}</div>}
    </section>
  );
}
