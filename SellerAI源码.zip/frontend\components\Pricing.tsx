"use client";

const plans = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    features: ["3 listings / month", "Basic listing generation", "Standard keywords", "Community support"],
    cta: "Get Started",
    highlight: true,
  },
  {
    name: "Starter",
    price: "$19.9",
    period: "/ month",
    features: [
      "100 listings / month",
      "Full listing generation",
      "Listing score analysis",
      "Advanced keywords",
      "Priority support",
    ],
    cta: "Start Trial",
    highlight: false,
  },
  {
    name: "Pro",
    price: "$49.9",
    period: "/ month",
    features: [
      "Unlimited listings",
      "Everything in Starter",
      "Bulk generation",
      "Competitor analysis",
      "Dedicated account manager",
    ],
    cta: "Start Trial",
    highlight: false,
  },
];

export default function Pricing({ onCta }: { onCta: () => void }) {
  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14">
          <h2 className="text-3xl sm:text-4xl font-bold text-text">Simple, Transparent Pricing</h2>
          <p className="mt-4 text-text-muted text-lg">Start free. Upgrade when you need more power.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative rounded-2xl p-8 border-2 transition-all duration-300 ${
                plan.highlight
                  ? "border-brand bg-white shadow-xl shadow-brand/10 scale-[1.03]"
                  : "border-gray-100 bg-white hover:shadow-lg hover:border-brand/30"
              }`}
            >
              {plan.highlight && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-brand text-white text-xs font-semibold rounded-full">
                  Most Popular
                </span>
              )}
              <div className="text-center">
                <h3 className="text-xl font-semibold text-text">{plan.name}</h3>
                <div className="mt-4">
                  <span className="text-4xl font-extrabold text-text">{plan.price}</span>
                  <span className="text-text-muted ml-1">{plan.period}</span>
                </div>
              </div>
              <ul className="mt-8 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 text-text-muted">
                    <svg className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={onCta}
                className={`mt-8 w-full py-3 text-sm font-semibold rounded-xl transition-colors cursor-pointer ${
                  plan.highlight
                    ? "bg-brand text-white hover:bg-brand-dark shadow-md"
                    : "border-2 border-brand text-brand hover:bg-brand hover:text-white"
                }`}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
