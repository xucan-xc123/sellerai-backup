# SellerAI Backend

Amazon Listing 优化器后端 API — Flask + DeepSeek (SiliconFlow 自动回退)

## 端点

| 方法 | 路径 | 说明 |
|------|------|------|
| `POST` | `/api/generate-listing` | 中文描述 → 结构化英文 Listing |
| `POST` | `/api/listing-score` | Listing 文本 → 8 维度诊断评分 |
| `GET`  | `/api/health` | 健康检查 |

## 快速开始

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置 API Key
cp .env.example .env
# 编辑 .env，填入 DEEPSEEK_API_KEY (必填) 和 SILICONFLOW_API_KEY (可选，用于回退)

# 3. 加载环境变量
# Windows PowerShell:
Get-Content .env | ForEach-Object {
    if ($_ -match '^\s*([^#].+?)=(.+)') { [Environment]::SetEnvironmentVariable($matches[1], $matches[2], 'Process') }
}

# Linux / macOS:
export $(cat .env | xargs)

# 4. 启动
python app.py
```

服务运行在 `http://localhost:8000`

## API 调用示例

### 生成 Listing

```bash
curl -X POST http://localhost:8000/api/generate-listing \
  -H "Content-Type: application/json" \
  -d '{"description": "一款便携式蓝牙音箱，支持防水防尘IPX7等级，续航12小时..."}'
```

### 评分

```bash
curl -X POST http://localhost:8000/api/listing-score \
  -H "Content-Type: application/json" \
  -d '{"listing": "Portable Bluetooth Speaker... full listing text"}'
```

## 运行测试

```bash
python test.py
```

## 部署到 Vercel

1. 安装 Vercel CLI: `npm i -g vercel`
2. 在 Vercel 项目设置中添加环境变量 `DEEPSEEK_API_KEY` 和 `SILICONFLOW_API_KEY`
3. 部署: `vercel`

## 架构

- **Primary**: DeepSeek API (deepseek-chat)
- **Fallback**: SiliconFlow (deepseek-ai/DeepSeek-V3)
- 15s 超时，5xx 自动重试 1 次
- CORS 全开，适配前端跨域
- 请求日志自动记录方法、路径、IP、耗时
