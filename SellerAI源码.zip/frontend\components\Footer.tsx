export default function Footer() {
  return (
    <footer className="py-8 border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-text-muted">
        &copy; {new Date().getFullYear()} SellerAI. Built by sellers, for sellers.
      </div>
    </footer>
  );
}
