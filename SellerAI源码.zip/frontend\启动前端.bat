@echo off
chcp 65001 >nul
title SellerAI - 前端

echo ================================
echo   SellerAI 前端启动中...
echo ================================
echo.
echo 后端 API：http://localhost:8000
echo 前端界面：http://localhost:3000
echo.
echo 不要关闭此窗口！
echo ================================
echo.

cd /d "%~dp0"

set DEEPSEEK_API_KEY=sk-a29e991690804089b774835b07d2b592

echo [1/2] 检查依赖...
if not exist "node_modules" (
    echo 首次运行，安装依赖中...
    call npm install
)

echo [2/2] 启动 Next.js...
npx next dev -p 3000

pause
