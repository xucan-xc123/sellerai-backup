"use client";

import { useState } from "react";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import Pricing from "@/components/Pricing";
import Footer from "@/components/Footer";
import ListingGenerator from "@/components/ListingGenerator";

export default function Home() {
  const [showTool, setShowTool] = useState(false);

  if (showTool) {
    return (
      <>
        <Navbar onBack={() => setShowTool(false)} />
        <ListingGenerator />
        <Footer />
      </>
    );
  }

  return (
    <>
      <Navbar onCta={() => setShowTool(true)} />
      <main className="flex-1">
        <Hero onCta={() => setShowTool(true)} />
        <Features />
        <Pricing onCta={() => setShowTool(true)} />
      </main>
      <Footer />
    </>
  );
}
