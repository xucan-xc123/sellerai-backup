// Internal API — calls Next.js API Routes (no separate backend needed)

interface RequestOptions {
  method?: string;
  body?: unknown;
  headers?: Record<string, string>;
}

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = "GET", body, headers = {} } = options;

  const res = await fetch(path, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...headers,
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: "Request failed" }));
    throw new Error(err.detail || err.error || `HTTP ${res.status}`);
  }

  return res.json();
}

// ─── Listing Generator ────────────────────────────────
export async function generateListing(description: string, temperature = 0.7) {
  return request<GenerateResponse>("/api/generate-listing", {
    method: "POST",
    body: { description, temperature },
  });
}

// ─── Types ────────────────────────────────────────────
export interface GenerateResponse {
  title: string;
  bullets: string[];
  description: string;
  keywords: string[];
  category_hints: string;
}
