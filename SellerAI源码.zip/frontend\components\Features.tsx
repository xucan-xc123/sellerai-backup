const features = [
  {
    icon: "🚀",
    title: "AI Listing Generator",
    desc: "Paste your product notes in Chinese, get a complete Amazon listing with title, bullets, description, and keywords in 60 seconds.",
  },
  {
    icon: "📊",
    title: "Listing Score",
    desc: "Get an 8-dimension diagnostic score for any listing. Know exactly what to fix before you publish.",
  },
  {
    icon: "🔑",
    title: "Keyword Tool",
    desc: "Generate high-converting backend search terms optimized for Amazon A9 algorithm.",
  },
];

export default function Features() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14">
          <h2 className="text-3xl sm:text-4xl font-bold text-text">
            Everything You Need to Sell on Amazon
          </h2>
          <p className="mt-4 text-text-muted text-lg">
            Built by sellers who&apos;ve done millions in revenue. No fluff, just tools that work.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((f) => (
            <div
              key={f.title}
              className="group p-8 rounded-2xl border border-gray-100 bg-card hover:shadow-lg hover:shadow-brand/5 hover:border-brand/20 transition-all duration-300"
            >
              <div className="text-4xl mb-4">{f.icon}</div>
              <h3 className="text-xl font-semibold text-text mb-3">{f.title}</h3>
              <p className="text-text-muted leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
