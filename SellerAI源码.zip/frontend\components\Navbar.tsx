"use client";

import { useState } from "react";

interface NavbarProps {
  onCta?: () => void;
  onBack?: () => void;
}

export default function Navbar({ onCta, onBack }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <a href="#" className="text-xl font-extrabold text-brand tracking-tight select-none">
            Seller<span className="text-text">AI</span>
          </a>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-4">
            {onBack ? (
              <button
                onClick={onBack}
                className="px-4 py-2 text-sm font-medium text-text-muted hover:text-text transition-colors rounded-lg hover:bg-gray-100 cursor-pointer"
              >
                ← Back
              </button>
            ) : onCta ? (
              <button
                onClick={onCta}
                className="px-5 py-2 text-sm font-semibold text-white bg-brand hover:bg-brand-dark transition-colors rounded-lg shadow-sm cursor-pointer"
              >
                Try It Free
              </button>
            ) : null}
          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            <svg className="w-6 h-6 text-text" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="md:hidden pb-4 flex flex-col gap-2">
            {onBack ? (
              <button
                onClick={() => { onBack(); setMobileOpen(false); }}
                className="px-4 py-2 text-sm font-medium text-left text-text-muted hover:text-text rounded-lg hover:bg-gray-100 cursor-pointer"
              >
                ← Back
              </button>
            ) : onCta ? (
              <button
                onClick={() => { onCta(); setMobileOpen(false); }}
                className="px-5 py-2 text-sm font-semibold text-white bg-brand hover:bg-brand-dark transition-colors rounded-lg shadow-sm text-center cursor-pointer"
              >
                Try It Free
              </button>
            ) : null}
          </div>
        )}
      </div>
    </nav>
  );
}
