import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SellerAI — AI-Powered Amazon Listing Generator",
  description:
    "Turn your product ideas into Amazon best sellers in 60 seconds. Paste your Chinese notes, get a ready-to-publish English listing.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="h-full antialiased">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-full flex flex-col font-sans" style={{ fontFamily: "Inter, sans-serif" }}>
        {children}
      </body>
    </html>
  );
}
