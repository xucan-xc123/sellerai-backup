import { NextRequest, NextResponse } from "next/server";

const DEEPSEEK_BASE = "https://api.deepseek.com/v1";
const DEEPSEEK_MODEL = "deepseek-chat";

const LISTING_PROMPT = `You are an expert Amazon listing copywriter. Given a Chinese product description, generate a complete Amazon listing in JSON format with these exact keys:
- "title": under 200 characters, include main keyword at front
- "bullets": array of 5 bullet points, each under 500 characters, start with CAPS BENEFIT then explain
- "description": full HTML product description, 500-1000 words, use <p><b><ul><li> tags
- "keywords": array of 10-15 backend search terms
- "category_hints": best Amazon category path

Rules:
- Write in native American English
- Focus on BENEFITS not features
- Include emotional triggers
- Optimize for Amazon A9 algorithm

Return ONLY valid JSON, no markdown fences, no extra text.`;

async function callDeepSeek(
  systemPrompt: string,
  userMessage: string,
  temperature = 0.7
) {
  const apiKey = process.env.DEEPSEEK_API_KEY;
  if (!apiKey) throw new Error("DEEPSEEK_API_KEY not configured");

  const resp = await fetch(`${DEEPSEEK_BASE}/chat/completions`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: DEEPSEEK_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage },
      ],
      temperature,
      response_format: { type: "json_object" },
    }),
    signal: AbortSignal.timeout(20000),
  });

  if (!resp.ok) {
    const errText = await resp.text().catch(() => "");
    throw new Error(`DeepSeek ${resp.status}: ${errText.slice(0, 200)}`);
  }

  const data = await resp.json();
  let content = data.choices[0].message.content.trim();

  // Strip ```json ... ``` fences if any
  if (content.startsWith("```")) {
    content = content.split("\n").slice(1).join("\n");
    if (content.endsWith("```")) content = content.slice(0, -3);
  }

  return JSON.parse(content.trim());
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const description = body.description?.trim();
    if (!description) {
      return NextResponse.json({ error: "Missing 'description'." }, { status: 400 });
    }

    const temperature = typeof body.temperature === "number" ? body.temperature : 0.7;
    const result = await callDeepSeek(LISTING_PROMPT, description, temperature);
    return NextResponse.json(result);
  } catch (err: any) {
    console.error("generate-listing error:", err.message);
    if (err.message?.includes("not configured")) {
      return NextResponse.json({ error: err.message }, { status: 500 });
    }
    return NextResponse.json({ error: "Generation failed.", detail: err.message }, { status: 502 });
  }
}
