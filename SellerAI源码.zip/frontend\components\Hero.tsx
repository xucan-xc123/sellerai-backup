export default function Hero({ onCta }: { onCta: () => void }) {
  return (
    <section className="relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-36 text-center">
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-text leading-tight max-w-4xl mx-auto">
          Turn Your Product Ideas Into{" "}
          <span className="text-brand">Amazon Best Sellers</span>
          {" "}— In 60 Seconds
        </h1>
        <p className="mt-6 text-lg sm:text-xl text-text-muted max-w-2xl mx-auto leading-relaxed">
          AI-powered listing generator built by real Amazon sellers. Paste your Chinese notes,
          get a ready-to-publish English listing.
        </p>
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onCta}
            className="w-full sm:w-auto px-8 py-3.5 text-base font-semibold text-white bg-brand hover:bg-brand-dark transition-colors rounded-xl shadow-lg shadow-brand/25 cursor-pointer"
          >
            Try Free
          </button>
          <button className="w-full sm:w-auto px-8 py-3.5 text-base font-semibold text-text border-2 border-gray-300 hover:border-gray-400 transition-colors rounded-xl cursor-pointer">
            View Demo
          </button>
        </div>
      </div>

      {/* Decorative blobs */}
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-brand/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-brand/5 rounded-full blur-3xl pointer-events-none" />
    </section>
  );
}
