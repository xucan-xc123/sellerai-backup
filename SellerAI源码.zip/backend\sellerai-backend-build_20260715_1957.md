# SellerAI Backend API — Build Summary

**Date:** 2026-07-15 19:57
**Task:** Build Python Flask API backend for SellerAI Listing Optimizer

## Files Created

| File | Purpose |
|------|---------|
| `app.py` | Flask entry point (12.4 KB) — 3 routes + middleware + LLM orchestration |
| `requirements.txt` | Dependencies: flask, flask-cors, requests, gunicorn |
| `.env.example` | Environment variable template |
| `vercel.json` | Vercel Serverless deployment config |
| `README.md` | Local run + deployment instructions |
| `test.py` | Integration test (starts Flask in thread, hits all endpoints) |

## API Endpoints

| Method | Path | Function |
|--------|------|----------|
| GET | `/api/health` | Health check — returns status + which providers are configured |
| POST | `/api/generate-listing` | `{"description":"..."}` → structured English listing JSON |
| POST | `/api/listing-score` | `{"listing":"..."}` → 8-dimension diagnostic score JSON |

## Architecture

- **Primary LLM:** DeepSeek API (`deepseek-chat`) via `DEEPSEEK_API_KEY`
- **Fallback:** SiliconFlow (`deepseek-ai/DeepSeek-V3`) via `SILICONFLOW_API_KEY`
- Fallback triggers automatically when DeepSeek is unreachable, returns 5xx, or key is missing
- 15s timeout per HTTP call, 1 retry on 5xx before falling through
- CORS fully open (`flask-cors`)
- Request logging: method, path, IP, status, latency (ms)

## Test Results

All non-LLM tests pass:
- ✅ Health endpoint returns `{"status":"ok"}`
- ✅ Input validation: missing/empty description → 400
- ✅ Unknown routes → 404
- ⚠️ LLM calls skipped (no API keys in test environment)

To test with real API keys, set `DEEPSEEK_API_KEY` (and optionally `SILICONFLOW_API_KEY`) then run `python test.py`.
