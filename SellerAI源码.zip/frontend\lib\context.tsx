"use client";

import { createContext, useContext, useState, useCallback, type ReactNode } from "react";

interface User {
  id: string;
  email: string;
  plan: "free" | "starter" | "pro";
  credits: number;
}

interface AuthContextValue {
  user: User | null;
  token: string | null;
  setSession: (user: User, token: string) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextValue>({
  user: null,
  token: null,
  setSession: () => {},
  logout: () => {},
  isAuthenticated: false,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);

  const setSession = useCallback((u: User, t: string) => {
    setUser(u);
    setToken(t);
    localStorage.setItem("sellerai_token", t);
    localStorage.setItem("sellerai_user", JSON.stringify(u));
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("sellerai_token");
    localStorage.removeItem("sellerai_user");
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        setSession,
        logout,
        isAuthenticated: !!user && !!token,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
